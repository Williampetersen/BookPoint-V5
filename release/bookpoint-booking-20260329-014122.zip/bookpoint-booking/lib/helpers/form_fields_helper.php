<?php
defined('ABSPATH') || exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- This file's wpdb SQL paths interpolate only hardcoded plugin table names with a sanitized WordPress prefix; dynamic values remain prepared or static by design.

function pointlybooking_install_form_fields_table() : void {
  global $wpdb;
  $charset_collate = $wpdb->get_charset_collate();
  $form_fields_table = $wpdb->prefix . 'pointlybooking_form_fields';

  $sql = "CREATE TABLE {$form_fields_table} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    field_key VARCHAR(80) NOT NULL,
    label VARCHAR(190) NOT NULL,
    type VARCHAR(30) NOT NULL DEFAULT 'text',
    scope VARCHAR(20) NOT NULL DEFAULT 'booking',
    step_key VARCHAR(30) NOT NULL DEFAULT 'details',
    placeholder VARCHAR(190) DEFAULT NULL,
    options LONGTEXT DEFAULT NULL,
    is_required TINYINT(1) NOT NULL DEFAULT 0,
    is_enabled TINYINT(1) NOT NULL DEFAULT 1,
    show_in_wizard TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    name_key VARCHAR(120) NULL,
    options_json LONGTEXT NULL,
    required TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_field_key_scope (field_key, scope),
    UNIQUE KEY scope_name_key (scope, name_key),
    KEY idx_scope_enabled (scope, is_enabled, sort_order),
    KEY idx_step (step_key),
    KEY scope (scope),
    KEY is_active (is_active),
    KEY sort_order (sort_order)
  ) {$charset_collate};";

  require_once ABSPATH . 'wp-admin/includes/upgrade.php';
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema management or uninstall cleanup is intentional here and cannot be cached.
  dbDelta($sql);
}

function pointlybooking_seed_default_form_fields() : void {
  // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names in this function are validated local plugin table names built from hardcoded plugin suffixes.
  global $wpdb;
  $form_fields_table = $wpdb->prefix . 'pointlybooking_form_fields';
  if (!preg_match('/^[A-Za-z0-9_]+$/', $form_fields_table)) {
    return;
  }

  $now = current_time('mysql');

  $defaults = [
    ['field_key'=>'first_name','label'=>'First name','type'=>'text','scope'=>'customer','step_key'=>'details','placeholder'=>'','is_required'=>1,'is_enabled'=>1,'show_in_wizard'=>1,'sort_order'=>10],
    ['field_key'=>'last_name','label'=>'Last name','type'=>'text','scope'=>'customer','step_key'=>'details','placeholder'=>'','is_required'=>0,'is_enabled'=>1,'show_in_wizard'=>1,'sort_order'=>20],
    ['field_key'=>'email','label'=>'Email','type'=>'email','scope'=>'customer','step_key'=>'details','placeholder'=>'','is_required'=>1,'is_enabled'=>1,'show_in_wizard'=>1,'sort_order'=>30],
    ['field_key'=>'phone','label'=>'Phone','type'=>'tel','scope'=>'customer','step_key'=>'details','placeholder'=>'','is_required'=>0,'is_enabled'=>1,'show_in_wizard'=>1,'sort_order'=>40],
    ['field_key'=>'notes','label'=>'Notes','type'=>'textarea','scope'=>'booking','step_key'=>'details','placeholder'=>'','is_required'=>0,'is_enabled'=>1,'show_in_wizard'=>1,'sort_order'=>10],
  ];

  foreach ($defaults as $f) {
    // Check if field already exists
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
    $exists = $wpdb->get_var(
      $wpdb->prepare(
        "SELECT id FROM {$form_fields_table} WHERE field_key=%s AND scope=%s",
        $f['field_key'],
        $f['scope']
      )
    );

    if ($exists) continue; // Skip if already exists

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
    $wpdb->insert($form_fields_table, [
      'field_key'=>$f['field_key'],
      'label'=>$f['label'],
      'type'=>$f['type'],
      'scope'=>$f['scope'],
      'step_key'=>$f['step_key'],
      'placeholder'=>$f['placeholder'],
      'options'=>null,
      'is_required'=>$f['is_required'],
      'is_enabled'=>$f['is_enabled'],
      'show_in_wizard'=>$f['show_in_wizard'],
      'sort_order'=>$f['sort_order'],
      'created_at'=>$now,
      'updated_at'=>$now,
      'name_key'=>$f['field_key'],
      'options_json'=>null,
      'required'=>$f['is_required'],
      'is_active'=>$f['is_enabled'],
    ], ['%s','%s','%s','%s','%s','%s','%s','%d','%d','%d','%d','%s','%s','%s','%s','%d','%d']);
  }
}
