<?php
defined('ABSPATH') || exit;

add_action('rest_api_init', function () {

  register_rest_route('pointly-booking/v1', '/admin/locations', [
    [
      'methods' => WP_REST_Server::READABLE,
      'permission_callback' => 'pointlybooking_rest_can_read_locations',
      'callback' => 'pointlybooking_rest_admin_locations_list',
    ],
    [
      'methods' => WP_REST_Server::CREATABLE,
      'permission_callback' => 'pointlybooking_rest_can_create_locations',
      'callback' => 'pointlybooking_rest_admin_locations_create',
    ],
  ]);

  register_rest_route('pointly-booking/v1', '/admin/locations/(?P<id>\d+)', [
    [
      'methods' => WP_REST_Server::READABLE,
      'permission_callback' => 'pointlybooking_rest_can_read_locations',
      'callback' => 'pointlybooking_rest_admin_locations_get',
    ],
    [
      'methods' => WP_REST_Server::EDITABLE,
      'permission_callback' => 'pointlybooking_rest_can_update_locations',
      'callback' => 'pointlybooking_rest_admin_locations_update',
    ],
    [
      'methods' => WP_REST_Server::DELETABLE,
      'permission_callback' => 'pointlybooking_rest_can_delete_locations',
      'callback' => 'pointlybooking_rest_admin_locations_delete',
    ],
  ]);

  register_rest_route('pointly-booking/v1', '/admin/locations/(?P<id>\d+)/agents', [
    [
      'methods' => WP_REST_Server::READABLE,
      'permission_callback' => 'pointlybooking_rest_can_read_location_agent_relations',
      'callback' => 'pointlybooking_rest_admin_locations_agents_get',
    ],
    [
      'methods' => WP_REST_Server::CREATABLE,
      'permission_callback' => 'pointlybooking_rest_can_manage_location_agent_relations',
      'callback' => 'pointlybooking_rest_admin_locations_agents_set',
    ],
  ]);

  register_rest_route('pointly-booking/v1', '/admin/location-categories', [
    [
      'methods' => WP_REST_Server::READABLE,
      'permission_callback' => 'pointlybooking_rest_can_read_location_categories',
      'callback' => 'pointlybooking_rest_admin_location_categories_list',
    ],
    [
      'methods' => WP_REST_Server::CREATABLE,
      'permission_callback' => 'pointlybooking_rest_can_create_location_categories',
      'callback' => 'pointlybooking_rest_admin_location_categories_create',
    ],
  ]);

  register_rest_route('pointly-booking/v1', '/admin/location-categories/(?P<id>\d+)', [
    [
      'methods' => WP_REST_Server::EDITABLE,
      'permission_callback' => 'pointlybooking_rest_can_update_location_categories',
      'callback' => 'pointlybooking_rest_admin_location_categories_update',
    ],
    [
      'methods' => WP_REST_Server::DELETABLE,
      'permission_callback' => 'pointlybooking_rest_can_delete_location_categories',
      'callback' => 'pointlybooking_rest_admin_location_categories_delete',
    ],
  ]);
});

function pointlybooking_rest_has_location_management_cap(): bool {
  $can_manage_settings = current_user_can('pointlybooking_manage_settings');
  $can_manage_options = current_user_can('manage_options');
  return $can_manage_settings || $can_manage_options;
}

function pointlybooking_rest_can_read_locations(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_create_locations(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_update_locations(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_delete_locations(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_read_location_agent_relations(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_manage_location_agent_relations(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_read_location_categories(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_create_location_categories(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_update_location_categories(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_delete_location_categories(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_rest_can_manage_locations(): bool {
  $allowed = pointlybooking_rest_has_location_management_cap();
  return $allowed;
}

function pointlybooking_locations_img_url($image_id, $size = 'thumbnail') {
  $id = (int)$image_id;
  if ($id <= 0) return '';
  $url = wp_get_attachment_image_url($id, $size);
  return $url ? $url : '';
}

function pointlybooking_locations_decode_json($value) {
  if (!$value) return null;
  $decoded = json_decode((string)$value, true);
  return is_array($decoded) ? $decoded : null;
}

function pointlybooking_locations_bool01($v) {
  return !empty($v) ? 1 : 0;
}

function pointlybooking_locations_require_tables() {
  if (class_exists('POINTLYBOOKING_Locations_Migrations_Helper')) {
    POINTLYBOOKING_Locations_Migrations_Helper::ensure_tables();
  }
}

function pointlybooking_rest_admin_locations_list() {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $locations_table = $wpdb->prefix . 'pointlybooking_locations';
  $categories_table = $wpdb->prefix . 'pointlybooking_location_categories';
  if (
    !preg_match('/^[A-Za-z0-9_]+$/', $locations_table)
    || !preg_match('/^[A-Za-z0-9_]+$/', $categories_table)
  ) {
    return rest_ensure_response(['status' => 'success', 'data' => []]);
  }

  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table identifiers are validated plugin table names built from $wpdb->prefix and fixed suffixes.
  $rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct admin read should stay uncached for fresh data.
    "SELECT l.*, c.name AS category_name, c.image_id AS category_image_id
       FROM {$locations_table} l
       LEFT JOIN {$categories_table} c ON c.id = l.category_id
       ORDER BY l.id DESC",
    ARRAY_A
  ) ?: [];

  foreach ($rows as &$r) {
    $r['image_id'] = (int)($r['image_id'] ?? 0);
    $r['image_url'] = pointlybooking_locations_img_url($r['image_id'], 'medium');
    $r['category_id'] = (int)($r['category_id'] ?? 0);
    $r['category_image_id'] = (int)($r['category_image_id'] ?? 0);
    $r['category_image_url'] = pointlybooking_locations_img_url($r['category_image_id'], 'thumbnail');
    $r['status'] = (string)($r['status'] ?? 'active');
    $r['is_active'] = $r['status'] === 'active' ? 1 : 0;
  }

  return rest_ensure_response(['status' => 'success', 'data' => $rows]);
}

function pointlybooking_rest_admin_locations_create(WP_REST_Request $req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $loc = $wpdb->prefix . 'pointlybooking_locations';
  $b = $req->get_json_params();
  if (!is_array($b)) $b = [];

  $now = current_time('mysql');
  $status = 'active';
  if (isset($b['status'])) {
    $s = sanitize_text_field((string)$b['status']);
    if ($s === 'inactive') $status = 'inactive';
  } elseif (array_key_exists('is_active', $b)) {
    $status = pointlybooking_locations_bool01($b['is_active']) ? 'active' : 'inactive';
  }

  $payload = [
    'status' => $status,
    'name' => sanitize_text_field($b['name'] ?? 'New Location'),
    'address' => sanitize_text_field($b['address'] ?? ''),
    'category_id' => !empty($b['category_id']) ? (int)$b['category_id'] : null,
    'image_id' => !empty($b['image_id']) ? (int)$b['image_id'] : null,
    'use_custom_schedule' => !empty($b['use_custom_schedule']) ? 1 : 0,
    'schedule_json' => !empty($b['schedule']) ? wp_json_encode($b['schedule']) : null,
    'created_at' => $now,
    'updated_at' => $now,
  ];

  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  $ok = $wpdb->insert($loc, $payload);
  if (!$ok) {
    return new WP_Error('pointlybooking_location_create_failed', $wpdb->last_error ?: 'DB insert failed', ['status' => 500]);
  }

  $id = (int)$wpdb->insert_id;
  return pointlybooking_rest_admin_locations_get(['id' => $id]);
}

function pointlybooking_rest_admin_locations_get($req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $id = (int)(is_array($req) ? ($req['id'] ?? 0) : $req['id']);
  if ($id <= 0) return new WP_Error('pointlybooking_location_invalid', 'Invalid id', ['status' => 400]);

  $loc = $wpdb->prefix . 'pointlybooking_locations';
  if (!preg_match('/^[A-Za-z0-9_]+$/', $loc)) {
    return new WP_Error('pointlybooking_location_invalid_table', 'Invalid locations table', ['status' => 500]);
  }

  $locations_table = $loc;
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table identifier is a validated plugin table name built from $wpdb->prefix and a fixed suffix.
  $row = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct admin read should stay uncached for fresh data.
    $wpdb->prepare("SELECT * FROM {$locations_table} WHERE id=%d", $id),
    ARRAY_A
  );
  if (!$row) return new WP_Error('pointlybooking_location_not_found', 'Location not found', ['status' => 404]);

  $row['image_id'] = (int)($row['image_id'] ?? 0);
  $row['image_url'] = pointlybooking_locations_img_url($row['image_id'], 'medium');
  $row['category_id'] = (int)($row['category_id'] ?? 0);
  $row['schedule'] = pointlybooking_locations_decode_json($row['schedule_json'] ?? null);
  $row['status'] = (string)($row['status'] ?? 'active');
  $row['is_active'] = $row['status'] === 'active' ? 1 : 0;

  return rest_ensure_response(['status' => 'success', 'data' => $row]);
}

function pointlybooking_rest_admin_locations_update(WP_REST_Request $req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $id = (int)$req['id'];
  if ($id <= 0) return new WP_Error('pointlybooking_location_invalid', 'Invalid id', ['status' => 400]);

  $loc = $wpdb->prefix . 'pointlybooking_locations';
  $b = $req->get_json_params();
  if (!is_array($b)) $b = [];

  $status = 'active';
  if (isset($b['status'])) {
    $s = sanitize_text_field((string)$b['status']);
    if ($s === 'inactive') $status = 'inactive';
  } elseif (array_key_exists('is_active', $b)) {
    $status = pointlybooking_locations_bool01($b['is_active']) ? 'active' : 'inactive';
  }

  $payload = [
    'status' => $status,
    'name' => sanitize_text_field($b['name'] ?? ''),
    'address' => sanitize_text_field($b['address'] ?? ''),
    'category_id' => !empty($b['category_id']) ? (int)$b['category_id'] : null,
    'image_id' => !empty($b['image_id']) ? (int)$b['image_id'] : null,
    'use_custom_schedule' => !empty($b['use_custom_schedule']) ? 1 : 0,
    'schedule_json' => array_key_exists('schedule', $b) ? wp_json_encode($b['schedule']) : null,
    'updated_at' => current_time('mysql'),
  ];

  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  $ok = $wpdb->update($loc, $payload, ['id' => $id]);
  if ($ok === false) {
    return new WP_Error('pointlybooking_location_update_failed', $wpdb->last_error ?: 'DB update failed', ['status' => 500]);
  }

  return pointlybooking_rest_admin_locations_get(['id' => $id]);
}

function pointlybooking_rest_admin_locations_delete(WP_REST_Request $req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $id = (int)$req['id'];
  if ($id <= 0) return new WP_Error('pointlybooking_location_invalid', 'Invalid id', ['status' => 400]);

  $loc = $wpdb->prefix . 'pointlybooking_locations';
  $map = $wpdb->prefix . 'pointlybooking_location_agents';

  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- This admin relation delete is an immediate write and should not be cached.
  $wpdb->delete($map, ['location_id' => $id], ['%d']);
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- This admin entity delete is an immediate write and should not be cached.
  $wpdb->delete($loc, ['id' => $id], ['%d']);

  return rest_ensure_response(['status' => 'success', 'data' => ['deleted' => true]]);
}

function pointlybooking_rest_admin_locations_agents_get(WP_REST_Request $req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $id = (int)$req['id'];
  if ($id <= 0) return new WP_Error('pointlybooking_location_invalid', 'Invalid id', ['status' => 400]);

  $map = $wpdb->prefix . 'pointlybooking_location_agents';
  if (!preg_match('/^[A-Za-z0-9_]+$/', $map)) {
    return new WP_Error('pointlybooking_location_invalid_table', 'Invalid location agents table', ['status' => 500]);
  }

  $map_table = $map;
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table identifier is a validated plugin table name built from $wpdb->prefix and a fixed suffix.
  $rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct admin read should stay uncached for fresh data.
    $wpdb->prepare("SELECT * FROM {$map_table} WHERE location_id=%d", $id),
    ARRAY_A
  ) ?: [];

  foreach ($rows as &$r) {
    $r['agent_id'] = (int)$r['agent_id'];
    $r['services'] = pointlybooking_locations_decode_json($r['services_json'] ?? null) ?: [];
  }

  return rest_ensure_response(['status' => 'success', 'data' => $rows]);
}

function pointlybooking_rest_admin_locations_agents_set(WP_REST_Request $req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $id = (int)$req['id'];
  if ($id <= 0) return new WP_Error('pointlybooking_location_invalid', 'Invalid id', ['status' => 400]);

  $map = $wpdb->prefix . 'pointlybooking_location_agents';
  $b = $req->get_json_params();
  if (!is_array($b)) $b = [];

  $agents = $b['agents'] ?? [];
  if (!is_array($agents)) $agents = [];

  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  $wpdb->delete($map, ['location_id' => $id], ['%d']);
  $now = current_time('mysql');

  foreach ($agents as $a) {
    $agent_id = (int)($a['agent_id'] ?? 0);
    if ($agent_id <= 0) continue;

    $services = $a['services'] ?? null;
    if (!is_array($services)) $services = null;
    $services_json = $services !== null ? wp_json_encode(array_values(array_unique(array_map('intval', $services)))) : null;

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
    $wpdb->insert($map, [
      'location_id' => $id,
      'agent_id' => $agent_id,
      'services_json' => $services_json,
      'created_at' => $now,
      'updated_at' => $now,
    ], ['%d','%d','%s','%s','%s']);
  }

  return rest_ensure_response(['status' => 'success', 'data' => ['saved' => true]]);
}

function pointlybooking_rest_admin_location_categories_list() {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $location_categories_table = $wpdb->prefix . 'pointlybooking_location_categories';
  if (!preg_match('/^[A-Za-z0-9_]+$/', $location_categories_table)) {
    return rest_ensure_response(['status' => 'success', 'data' => []]);
  }

  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table identifier is a validated plugin table name built from $wpdb->prefix and a fixed suffix.
  $rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct admin read should stay uncached for fresh data.
    "SELECT * FROM {$location_categories_table} WHERE status='active' ORDER BY id DESC",
    ARRAY_A
  ) ?: [];

  foreach ($rows as &$r) {
    $r['image_id'] = (int)($r['image_id'] ?? 0);
    $r['image_url'] = pointlybooking_locations_img_url($r['image_id'], 'thumbnail');
  }

  return rest_ensure_response(['status' => 'success', 'data' => $rows]);
}

function pointlybooking_rest_admin_location_categories_create(WP_REST_Request $req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $t = $wpdb->prefix . 'pointlybooking_location_categories';
  $b = $req->get_json_params();
  if (!is_array($b)) $b = [];

  $name = sanitize_text_field($b['name'] ?? '');
  if ($name === '') {
    return new WP_Error('pointlybooking_location_category_invalid', 'Name is required', ['status' => 400]);
  }

  $now = current_time('mysql');
  $payload = [
    'status' => 'active',
    'name' => $name,
    'image_id' => !empty($b['image_id']) ? (int)$b['image_id'] : null,
    'created_at' => $now,
    'updated_at' => $now,
  ];

  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  $ok = $wpdb->insert($t, $payload);
  if (!$ok) {
    return new WP_Error('pointlybooking_location_category_create_failed', $wpdb->last_error ?: 'DB insert failed', ['status' => 500]);
  }

  return pointlybooking_rest_admin_location_categories_list();
}

function pointlybooking_rest_admin_location_categories_update(WP_REST_Request $req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $id = (int)$req['id'];
  if ($id <= 0) return new WP_Error('pointlybooking_location_category_invalid', 'Invalid id', ['status' => 400]);

  $t = $wpdb->prefix . 'pointlybooking_location_categories';
  $b = $req->get_json_params();
  if (!is_array($b)) $b = [];

  $u = [
    'status' => 'active',
    'updated_at' => current_time('mysql'),
  ];
  if (isset($b['name'])) $u['name'] = sanitize_text_field($b['name']);
  if (array_key_exists('image_id', $b)) $u['image_id'] = !empty($b['image_id']) ? (int)$b['image_id'] : null;

  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  $ok = $wpdb->update($t, $u, ['id' => $id]);
  if ($ok === false) {
    return new WP_Error('pointlybooking_location_category_update_failed', $wpdb->last_error ?: 'DB update failed', ['status' => 500]);
  }

  return pointlybooking_rest_admin_location_categories_list();
}

function pointlybooking_rest_admin_location_categories_delete(WP_REST_Request $req) {
  global $wpdb;
  pointlybooking_locations_require_tables();

  $id = (int)$req['id'];
  if ($id <= 0) return new WP_Error('pointlybooking_location_category_invalid', 'Invalid id', ['status' => 400]);

  $t = $wpdb->prefix . 'pointlybooking_location_categories';
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database access is intentional here; result freshness or surrounding logic makes local persistent caching inappropriate for this path.
  $wpdb->delete($t, ['id' => $id], ['%d']);

  return rest_ensure_response(['status' => 'success', 'data' => ['deleted' => true]]);
}
